<?php
// api.php
header('Content-Type: application/json');
error_reporting(0); // Ocultar warnings de HTML mal formatado

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método inválido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$url = filter_var($input['url'] ?? '', FILTER_VALIDATE_URL);

if (!$url) {
    echo json_encode(['error' => 'URL inválida ou vazia.']);
    exit;
}

// Função para fazer requisição cURL (simulando um navegador real)
function fetchUrl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    // Simulação mais completa de um navegador moderno:
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control: no-cache',
        'Pragma: no-cache'
    ]);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
}

// Função para converter imagem remota em Base64 (Evita erro de CORS no JS)
function imageToBase64($url) {
    $imageData = fetchUrl($url);
    if ($imageData) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $type = $finfo->buffer($imageData);
        return 'data:' . $type . ';base64,' . base64_encode($imageData);
    }
    return null;
}

$html = fetchUrl($url);

if (!$html) {
    echo json_encode(['error' => 'Não foi possível acessar o site.']);
    exit;
}

// Parse do HTML
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
libxml_clear_errors();
$xpath = new DOMXPath($doc);

// 1. Extrair Título
$title = '';
$ogTitle = $xpath->query('//meta[@property="og:title"]/@content');
if ($ogTitle->length > 0) {
    $title = $ogTitle->item(0)->nodeValue;
} else {
    $tagsTitle = $doc->getElementsByTagName('title');
    if ($tagsTitle->length > 0) $title = $tagsTitle->item(0)->nodeValue;
}

// 2. Extrair Imagem
$imageUrl = '';
$ogImage = $xpath->query('//meta[@property="og:image"]/@content');
if ($ogImage->length > 0) {
    $imageUrl = $ogImage->item(0)->nodeValue;
} else {
    // Tenta pegar a primeira imagem relevante
    $imgs = $doc->getElementsByTagName('img');
    if ($imgs->length > 0) {
        $imageUrl = $imgs->item(0)->getAttribute('src');
    }
}

// Corrigir URL relativa da imagem se necessário
if ($imageUrl && strpos($imageUrl, 'http') !== 0) {
    $parsedUrl = parse_url($url);
    $root = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
    $imageUrl = $root . '/' . ltrim($imageUrl, '/');
}

// 3. Extrair Descrição/Texto
$description = '';
$ogDesc = $xpath->query('//meta[@property="og:description"]/@content');
if ($ogDesc->length > 0) {
    $description = $ogDesc->item(0)->nodeValue;
} else {
    // Tenta pegar o primeiro parágrafo longo
    $paragraphs = $doc->getElementsByTagName('p');
    foreach ($paragraphs as $p) {
        if (strlen($p->nodeValue) > 50) {
            $description = $p->nodeValue;
            break;
        }
    }
}

// Limitar texto para caber no card
$description = mb_strimwidth($description, 0, 150, "...");

// 4. Fonte e Data
$parsedUrl = parse_url($url);
$source = $parsedUrl['host'];
$date = date('d/m/Y'); 

// Converter imagem para Base64 para evitar bloqueio no Canvas
$base64Image = $imageUrl ? imageToBase64($imageUrl) : null;

echo json_encode([
    'success' => true,
    'title' => trim($title),
    'text' => trim($description),
    'image' => $base64Image,
    'source' => $source,
    'date' => $date
]);
?>