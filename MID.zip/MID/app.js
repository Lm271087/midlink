document.addEventListener('DOMContentLoaded', () => {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const urlInput = document.getElementById('urlInput');
    const loading = document.getElementById('loading');
    const errorMsg = document.getElementById('errorMsg');
    const cardContainer = document.getElementById('cardContainer');
    const tools = document.getElementById('tools');
    
    // Elementos do Card
    const cardImg = document.getElementById('cardImg');
    const cardTitle = document.getElementById('cardTitle');
    const cardText = document.getElementById('cardText');
    const cardSource = document.getElementById('cardSource');
    const cardDate = document.getElementById('cardDate');

    // Botões de Ação
    const uploadImg = document.getElementById('uploadImg');
    const downloadBtn = document.getElementById('downloadBtn');
    const shareBtn = document.getElementById('shareBtn');
    const captureArea = document.getElementById('captureArea');

    // 1. Analisar URL
    analyzeBtn.addEventListener('click', async () => {
        const url = urlInput.value.trim();
        if (!url) return;

        resetUI();
        loading.classList.remove('hidden');

        try {
            const response = await fetch('api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: url })
            });

            const data = await response.json();

            if (data.error) {
                showError(data.error);
            } else {
                populateCard(data);
            }
        } catch (err) {
            showError('Erro de conexão com o servidor.');
        } finally {
            loading.classList.add('hidden');
        }
    });

    // 2. Preencher Card com Dados
    function populateCard(data) {
        cardTitle.textContent = data.title || 'Sem título';
        cardText.textContent = data.text || 'Sem descrição disponível.';
        cardSource.textContent = `Fonte: ${data.source}`;
        cardDate.textContent = `Data: ${data.date}`;
        
        if (data.image) {
            cardImg.src = data.image; // Já vem em Base64 do PHP
        } else {
            // Imagem padrão caso não tenha
            cardImg.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg width="800" height="600" xmlns="http://www.w3.org/2000/svg"%3E%3Crect width="100%25" height="100%25" fill="%23ddd"/%3E%3Ctext x="50%25" y="50%25" fill="%23555" text-anchor="middle"%3ESem Imagem%3C/text%3E%3C/svg%3E';
        }

        cardContainer.classList.remove('hidden');
        tools.classList.remove('hidden');
    }

    // 3. Upload de Imagem Local
    uploadImg.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                cardImg.src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });

    // 4. Download da Imagem
    downloadBtn.addEventListener('click', () => {
        generateImage().then(canvas => {
            const link = document.createElement('a');
            link.download = `midlink-${Date.now()}.png`;
            link.href = canvas.toDataURL('image/png');
            link.click();
        });
    });

    // 5. Compartilhar
    shareBtn.addEventListener('click', async () => {
        if (navigator.share) {
            try {
                const canvas = await generateImage();
                canvas.toBlob(async (blob) => {
                    const file = new File([blob], "midlink-share.png", { type: "image/png" });
                    await navigator.share({
                        title: cardTitle.textContent,
                        text: cardText.textContent,
                        files: [file]
                    });
                });
            } catch (err) {
                console.error("Erro ao compartilhar", err);
                alert('Seu navegador não suporta compartilhamento direto de imagem.');
            }
        } else {
            alert('Compartilhamento não suportado neste navegador. Use o botão Baixar.');
        }
    });

    // Função Auxiliar para html2canvas
    function generateImage() {
        return html2canvas(captureArea, {
            scale: 2, // Melhor resolução
            useCORS: true, // Importante, embora o Base64 já resolva a maioria
            backgroundColor: null
        });
    }

    function resetUI() {
        errorMsg.classList.add('hidden');
        cardContainer.classList.add('hidden');
        tools.classList.add('hidden');
    }

    function showError(msg) {
        errorMsg.textContent = msg;
        errorMsg.classList.remove('hidden');
    }
});